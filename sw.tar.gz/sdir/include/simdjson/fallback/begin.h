#define SIMDJSON_IMPLEMENTATION fallback
#include "simdjson/fallback/base.h"
#include "simdjson/fallback/bitmanipulation.h"
#include "simdjson/fallback/stringparsing_defs.h"
#include "simdjson/fallback/numberparsing_defs.h"
